<?php

require APPPATH . 'libraries/REST_Controller.php';
class IVR extends REST_Controller
{

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function index_put()
    {
        $data=json_decode(file_get_contents("php://input"));

        if(empty($data) || $data == null)
        {
            $this->response(['Parameters are missing.'], REST_Controller::HTTP_OK);
        }

        if(!isset($data->IVR_ID))
        {
            $res["success"]=false;
            $res["message"]="IVR ID is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        if($data->type != "custom"){
            $this->ValidateInput($data);
        

        $this->load->model('IVR_model');

        $this->IVR_model->update_ivr($data);

        $digits=get_object_vars($data);
        
        $this->IVR_model->delete_ivr_entries($data->IVR_ID);
        $len=count($digits);
        for($i=1;$i<$len;$i++)
        {
            $ary_name="Digits".$i;
            if(isset($digits[$ary_name]))
            {
                $digit=$digits[$ary_name];

                if(!empty($digit) || $digit != null)
                {
                    $this->insert_entries($digit,$data->IVR_ID);
                }
            }
        }

        //shell_exec('amportal reload');
        $res["success"]=true;
        $res["message"]="IVR Updated successfully. IVR ID:".$data->IVR_ID;
        $this->response($res,REST_Controller::HTTP_OK);

        }else{
            $this->load->model('IVR_model');
            $this->IVR_model->update_ivr($data);

            $res["success"]=true;
            $res["message"]="Custom IVR Updated successfully. IVR ID:".$data->IVR_ID;
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }

    public function index_post()
    {
        $data=json_decode(file_get_contents("php://input"));

        if(empty($data) || $data == null)
        {
            $this->response(['Parameters are missing.'], REST_Controller::HTTP_OK);
        }

        if(isset($data->type) && $data->type !="custom"){
            $this->ValidateInput($data);
        }
   

        $this->load->model('IVR_model');

        $ivr_id= $this->IVR_model->create_ivr($data);

        $digits=get_object_vars($data);
        $len=count($digits);
        for($i=1;$i<$len;$i++)
        {
            $ary_name="Digits".$i;
            if(isset($digits[$ary_name]))
            {
                $digit=$digits[$ary_name];

                if(!empty($digit) || $digit != null)
                {
                    $this->insert_entries($digit,$ivr_id);
                }
            }
        }

        //shell_exec('amportal reload');
        $res["success"]=true;
        $res["message"]="IVR created successfully. IVR ID:".$ivr_id;
        $this->response($res,REST_Controller::HTTP_OK);
    }

    public function insert_entries($data,$ivr_id)
    {
        $this->load->model('IVR_model');
        if(!isset($data->digit))
        {
            $res["success"]=false;
            $res["message"]="IVR Created but entries digit is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->destination))
        {
            $res["success"]=false;
            $res["message"]="IVR Created but entries destination is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->return))
        {
            $res["success"]=false;
            $res["message"]="IVR Created but entries return is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        $this->IVR_model->insert_ivr_entries($data,$ivr_id);
    }

    public function index_delete($id=0)
    {
        if(!empty($id))
        {
            $this->load->model('IVR_model');
            $ivr_id= $this->IVR_model->delete_ivr($id);
            if($ivr_id == true)
            {
                $res["success"]=true;
                $res["message"]="IVR has been deleted.";
                $this->response($res,REST_Controller::HTTP_OK);
            }
            else
            {
                $res["success"]=false;
                $res["message"]="IVR Not Exists.";
                $this->response($res,REST_Controller::HTTP_OK);   
            }
        }
        else
        {
            $res["success"]=false;
            $res["message"]="IVR ID is missing.";
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }


    public function index_get($id='')
    {
        $this->load->model('IVR_model');
        if(!empty($id))
        {
            $ivr_details= $this->IVR_model->get_ivr($id);
            $data=$ivr_details;
            if(count($ivr_details) > 0)
            {
                    $res=$data[0];
                    if(isset($res["ivr_entries"])){
                        unset($data[0]["ivr_entries"]);
                        $data['ivr_entries'] = $res["ivr_entries"];
                        unset($res["ivr_entries"]);
                        
                    }else{
                        $ivrid=$res['id'];
                        $ivr_entries =$this->IVR_model->get_ivr_entries($ivrid);
                        $data['ivr_entries']=$ivr_entries;
                    } 
                }
                
            $this->response($data, REST_Controller::HTTP_OK);
        }
        else
        {
            $data = $this->IVR_model->get_all_ivr();
            $this->response($data, REST_Controller::HTTP_OK);
        }
        
    }

    public function ValidateInput($data)
    {
        $res=array();
        if(!isset($data->IVRName))
        {
            $res["success"]=false;
            $res["message"]="IVR Name is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->IVRDescription))
        {
            $res["success"]=false;
            $res["message"]="IVR Description is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->Announcement))
        {
            $res["success"]=false;
            $res["message"]="Announcement is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->ForceStrictDialTimeout))
        {
            $res["success"]=false;
            $res["message"]="Force Strict Dial Timeout is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->Timeout))
        {
            $res["success"]=false;
            $res["message"]="Timeout is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->AlertInfo))
        {
            $res["success"]=false;
            $res["message"]="Alert Info is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->RingerVolumeOverride))
        {
            $res["success"]=false;
            $res["message"]="Ringer Volume Override is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->InvalidRetries))
        {
            $res["success"]=false;
            $res["message"]="Invalid Retries is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->InvalidRetryRecording))
        {
            $res["success"]=false;
            $res["message"]="Invalid Retry Recording is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->AppendAnnouncementtoInvalid))
        {
            $res["success"]=false;
            $res["message"]="Append Announcement to Invalid is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->ReturnonInvalid))
        {
            $res["success"]=false;
            $res["message"]="Returnon Invalid is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->InvalidRecording))
        {
            $res["success"]=false;
            $res["message"]="Invalid Recording is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->InvalidDestination))
        {
            $res["success"]=false;
            $res["message"]="Invalid Destination is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->TimeoutRetries))
        {
            $res["success"]=false;
            $res["message"]="Timeout Retries is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->TimeoutRetryRecording))
        {
            $res["success"]=false;
            $res["message"]="Timeout Retry Recording is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->AppendAnnouncementonTimeout))
        {
            $res["success"]=false;
            $res["message"]="Append Announcement on Timeout is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->ReturnonTimeout))
        {
            $res["success"]=false;
            $res["message"]="Return on Timeout is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->TimeoutRecording))
        {
            $res["success"]=false;
            $res["message"]="Timeout Recording is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->TimeoutDestination))
        {
            $res["success"]=false;
            $res["message"]="Timeout Destination is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->ReturntoIVRafterVM))
        {
            $res["success"]=false;
            $res["message"]="Return to IVR after VM is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }


}

