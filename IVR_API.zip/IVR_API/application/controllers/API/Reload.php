<?php

require APPPATH . 'libraries/REST_Controller.php';
class Reload extends REST_Controller
{

    public function __construct() {
        parent::__construct();
    }

    public function index_get()
    {
        shell_exec('amportal reload');
        $res["success"]=true;
        $res["message"]="Reload successfully.";
        $this->response($res,REST_Controller::HTTP_OK);
    }
}