<?php

require APPPATH . 'libraries/REST_Controller.php';
class Misc_Application extends REST_Controller
{

    public function __construct() {
        parent::__construct();
    }

    public function index_put()
    {
        $data=json_decode(file_get_contents("php://input"));

        if(empty($data) || $data == null)
        {
            $this->response(['Parameters are missing.'], REST_Controller::HTTP_OK);
        }

        if(!isset($data->miscapps_id))
        {
            $res["success"]=false;
            $res["message"]="Misc application ID is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }

        $this->ValidateInput($data);

        $this->load->model('Misc_application_model');

        $row=$this->Misc_application_model->update_misc($data);
        if($row > 0)
        {
            $this->Misc_application_model->update_misc_featurecode("miscapp_".$data->miscapps_id,$data->description,"",$data->ext,"","1","0");
            $res["success"]=true;
            $res["message"]="Misc application Updated successfully. Misc ID:".$data->miscapps_id;
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else
        {
            $res["success"]=false;
            $res["message"]="Misc application Not found";
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }

    public function index_post()
    {
        $data=json_decode(file_get_contents("php://input"));

        if(empty($data) || $data == null)
        {
            $this->response(['Parameters are missing.'], REST_Controller::HTTP_OK);
        }

        $this->ValidateInput($data);

        $this->load->model('Misc_application_model');

        $misc_id= $this->Misc_application_model->create_misc($data);

        $this->Misc_application_model->create_misc_feature_code("miscapp_".$misc_id,$data->description,"",$data->ext,"","1","0");
        
        $res["success"]=true;
        $res["message"]="Misc application created successfully. Misc application ID:".$misc_id;
        $this->response($res,REST_Controller::HTTP_OK);
    }

    public function index_delete($id=0)
    {
        if(!empty($id))
        {
            $this->load->model('Misc_application_model');
            $misc_id= $this->Misc_application_model->delete_misc($id);
            if($misc_id == true)
            {
                $this->Misc_application_model->delete_featurecodes("miscapp_".$id);
                $res["success"]=true;
                $res["message"]="Misc Application has been deleted.";
                $this->response($res,REST_Controller::HTTP_OK);
            }
            else
            {
                $res["success"]=false;
                $res["message"]="Misc Application Not Exists.";
                $this->response($res,REST_Controller::HTTP_OK);   
            }
        }
        else
        {
            $res["success"]=false;
            $res["message"]="Misc Application ID is missing.";
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }


    public function index_get($id='')
    {
        $this->load->model('Misc_application_model');
        if(!empty($id))
        {
            $miscapp= $this->Misc_application_model->get_misc($id);
            $data=$miscapp;
            
            $this->response($data, REST_Controller::HTTP_OK);
        }
        else
        {
            $data = $this->Misc_application_model->get_all_misc();
            $this->response($data, REST_Controller::HTTP_OK);
        }
        
    }

    public function ValidateInput($data)
    {
        $res=array();
        if(!isset($data->description))
        {
            $res["success"]=false;
            $res["message"]="Description is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->dest))
        {
            $res["success"]=false;
            $res["message"]="Destination is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->ext))
        {
            $res["success"]=false;
            $res["message"]="extension is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }


}

