<?php

require APPPATH . 'libraries/REST_Controller.php';
class Misc_Destination extends REST_Controller
{

    public function __construct() {
        parent::__construct();
    }

    public function index_put()
    {
        $data=json_decode(file_get_contents("php://input"));

        if(empty($data) || $data == null)
        {
            $this->response(['Parameters are missing.'], REST_Controller::HTTP_OK);
        }

        if(!isset($data->Misc_ID))
        {
            $res["success"]=false;
            $res["message"]="Misc Destination ID is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }

        $this->ValidateInput($data);

        $this->load->model('Misc_destination_model');

        $row=$this->Misc_destination_model->update_misc($data);
        if($row > 0)
        {
            $res["success"]=true;
            $res["message"]="Misc destination Updated successfully. Misc ID:".$data->Misc_ID;
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else
        {
            $res["success"]=false;
            $res["message"]="Misc destination Not found";
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }

    public function index_post()
    {
        $data=json_decode(file_get_contents("php://input"));

        if(empty($data) || $data == null)
        {
            $this->response(['Parameters are missing.'], REST_Controller::HTTP_OK);
        }

        $this->ValidateInput($data);

        $this->load->model('Misc_destination_model');

        $misc_id= $this->Misc_destination_model->create_misc($data);
        
        $res["success"]=true;
        $res["message"]="Misc destination created successfully. Misc destination ID:".$misc_id;
        $this->response($res,REST_Controller::HTTP_OK);
    }

    public function index_delete($id=0)
    {
        if(!empty($id))
        {
            $this->load->model('Misc_destination_model');
            $misc_id= $this->Misc_destination_model->delete_misc($id);
            if($misc_id == true)
            {
                $res["success"]=true;
                $res["message"]="Misc Destination has been deleted.";
                $this->response($res,REST_Controller::HTTP_OK);
            }
            else
            {
                $res["success"]=false;
                $res["message"]="Misc Destination Not Exists.";
                $this->response($res,REST_Controller::HTTP_OK);   
            }
        }
        else
        {
            $res["success"]=false;
            $res["message"]="Misc Destination ID is missing.";
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }


    public function index_get($id='')
    {
        $this->load->model('Misc_destination_model');
        if(!empty($id))
        {
            $miscdests= $this->Misc_destination_model->get_misc($id);
            $data=$miscdests;
            
            $this->response($data, REST_Controller::HTTP_OK);
        }
        else
        {
            $data = $this->Misc_destination_model->get_all_misc();
            $this->response($data, REST_Controller::HTTP_OK);
        }
        
    }

    public function ValidateInput($data)
    {
        $res=array();
        if(!isset($data->description))
        {
            $res["success"]=false;
            $res["message"]="Description is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->destination_dial))
        {
            $res["success"]=false;
            $res["message"]="Destination dial is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }


}

