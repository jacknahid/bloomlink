<?php

require APPPATH . 'libraries/REST_Controller.php';
class Recording extends REST_Controller
{

    public function __construct() {
        parent::__construct();
    }

    public function index_put()
    {
        $data=json_decode(file_get_contents("php://input"));

        if(empty($data) || $data == null)
        {
            $this->response(['Parameters are missing.'], REST_Controller::HTTP_OK);
        }

        if(!isset($data->id))
        {
            $res["success"]=false;
            $res["message"]="Recording ID is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }

        $this->ValidateInput($data);

        $this->load->model('Recording_model');

        $recording_id= $this->Recording_model->update_recording($data);

        if($recording_id > 0)
        {
            $res["success"]=true;
            $res["message"]="Recording updated successfully. Recording ID:".$data->id;
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else
        {
            $res["success"]=false;
            $res["message"]="Recording not found.";
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }

    public function index_delete($id=0)
    {
        if(!empty($id))
        {
            $this->load->model('Recording_model');
            $ivr_id= $this->Recording_model->delete_recording($id);
            if($ivr_id == true)
            {
                $res["success"]=true;
                $res["message"]="Recording has been deleted.";
                $this->response($res,REST_Controller::HTTP_OK);
            }
            else
            {
                $res["success"]=false;
                $res["message"]="Recording Not Exists.";
                $this->response($res,REST_Controller::HTTP_OK);   
            }
        }
        else
        {
            $res["success"]=false;
            $res["message"]="Recoridng ID is missing.";
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }

    public function index_post()
    {
        $data=json_decode(file_get_contents("php://input"));

        if(empty($data) || $data == null)
        {
            $this->response(['Parameters are missing.'], REST_Controller::HTTP_OK);
        }

        $this->ValidateInput($data);

        $this->load->model('Recording_model');

        $recording_id= $this->Recording_model->create_recording($data);

        $res["success"]=true;
        $res["message"]="Recording created successfully. Recording ID:".$recording_id;
        $this->response($res,REST_Controller::HTTP_OK);
    }

    public function index_get($id='')
    {
        $this->load->model('Recording_model');
        if(!empty($id))
        {
            $recording_details= $this->Recording_model->get_recording($id);
            $data=$recording_details;
            $this->response($data, REST_Controller::HTTP_OK);
        }
        else
        {
            $data = $this->Recording_model->get_all_recording();
            $this->response($data, REST_Controller::HTTP_OK);
        }
        
    }

    public function ValidateInput($data)
    {
        $res=array();
        if(!isset($data->displayname))
        {
            $res["success"]=false;
            $res["message"]="Display Name is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->filename) || strpos($data->filename,"custom/") === false)
        {
            $res["success"]=false;
            $res["message"]="File name is missing or Pattern not match (custom/)";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->description))
        {
            $res["success"]=false;
            $res["message"]="Description is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->fcode))
        {
            $res["success"]=false;
            $res["message"]="fcode is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->fcode_pass))
        {
            $res["success"]=false;
            $res["message"]="fcode_pass is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
        else if (!isset($data->fcode_lang))
        {
            $res["success"]=false;
            $res["message"]="fcode_lang is missing";
            $this->response($res,REST_Controller::HTTP_OK);
        }
    }



}

?>