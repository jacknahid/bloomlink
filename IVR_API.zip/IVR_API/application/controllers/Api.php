<?php

class Api extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        echo "<h1> Hello rafaqat </h1>";
    }
}