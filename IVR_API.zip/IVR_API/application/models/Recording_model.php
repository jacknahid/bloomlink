<?php

class Recording_model extends CI_Model{
    
    public function get_recording($id)
    {
        $q="select * from recordings where id=".$id;
        $query = $this->db->query($q);
        $recording_details = $query->result_array();
        return $recording_details;
    }

    public function get_all_recording()
    {
        $q="select * from recordings";
        $query = $this->db->query($q);
        $recording_details = $query->result_array();
        return $recording_details;
    }

    public function update_recording($data)
    {
        $q="insert into recordings (displayname,filename,description,fcode,fcode_pass,fcode_lang)
        values ('".$data->displayname."','".$data->filename."','".$data->description."','".$data->fcode."','".$data->fcode_pass."','".$data->fcode_lang."')";
        $q="update recordings 
        set displayname='".$data->displayname."',filename='".$data->filename."',description='".$data->description."',fcode='".$data->fcode."',fcode_pass='".$data->fcode_pass."',fcode_lang='".$data->fcode_lang."'
        where id=".$data->id;
        $query=$this->db->query($q);
        $recording_id = $this->db->affected_rows();
        return $recording_id;
    }

    public function create_recording($data)
    {
        $q="insert into recordings (displayname,filename,description,fcode,fcode_pass,fcode_lang)
        values ('".$data->displayname."','".$data->filename."','".$data->description."','".$data->fcode."','".$data->fcode_pass."','".$data->fcode_lang."')";
        $query=$this->db->query($q);
        $recording_id = $this->db->insert_id();
        return $recording_id;
    }

    public function delete_recording($id)
    {
        $q="delete from recordings where id=".$id;
        $query=$this->db->query($q);
        return $this->db->affected_rows();
    }
}

?>