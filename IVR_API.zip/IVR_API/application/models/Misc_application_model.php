<?php

class Misc_application_model extends CI_Model{
    
    public function get_misc($id)
    {
        $q="select * from miscapps where miscapps_id=".$id;
        $query = $this->db->query($q);
        $miscapp = $query->result_array();
        return $miscapp;
    }

    public function get_all_misc()
    {
        $q="select * from miscapps";
        $query = $this->db->query($q);
        $miscapp = $query->result_array();
        return $miscapp;
    }

    public function create_misc($data)
    {
        $q="insert into miscapps (description,dest,ext) values ('".$data->description."','".$data->dest."','".$data->ext."');";
        $query=$this->db->query($q);
        $misc_id = $this->db->insert_id();
        return $misc_id;
    }

    public function create_misc_feature_code($featurename,$description,$helptext,$default_code,$customcode,$enabled,$providedest)
    {
        $q="insert into featurecodes (modulename,featurename,description,helptext,defaultcode,customcode,enabled,providedest) values ('miscapps','".$featurename."','".$description."','".$helptext."','".$default_code."','".$customcode."','".$enabled."','".$providedest."');";
        $query=$this->db->query($q);
        $featurecode = $this->db->insert_id();
        return $featurecode;
    }

    public function update_misc($data)
    {
        $q="update miscapps set description='".$data->description."',dest='".$data->dest."',ext='".$data->ext."' where miscapps_id=".$data->miscapps_id;
        $query=$this->db->query($q);
        return $this->db->affected_rows();
    }

    public function update_misc_featurecode($featurename,$description,$helptext,$default_code,$customcode,$enabled,$providedest)
    {
        $q="update featurecodes set description='".$description."',helptext='".$helptext."',defaultcode='".$default_code."',customcode='".$customcode."',enabled='".$enabled."',providedest='".$providedest."' where featurename='".$featurename."' ";
        $query=$this->db->query($q);
        return $this->db->affected_rows();
    }

    public function delete_misc($id)
    {
        $q="delete from miscapps where miscapps_id=".$id;
        $query=$this->db->query($q);
        return $this->db->affected_rows();
    }

    public function delete_featurecodes($featurename)
    {
        $q="delete from featurecodes where featurename='".$featurename."'";
        $query=$this->db->query($q);
        return $this->db->affected_rows();
    }
}

?>