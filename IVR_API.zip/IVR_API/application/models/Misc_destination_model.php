<?php

class Misc_destination_model extends CI_Model{
    
    public function get_misc($id)
    {
        $q="select * from miscdests where id=".$id;
        $query = $this->db->query($q);
        $miscdests = $query->result_array();
        return $miscdests;
    }

    public function get_all_misc()
    {
        $q="select * from miscdests";
        $query = $this->db->query($q);
        $miscdests = $query->result_array();
        return $miscdests;
    }

    public function create_misc($data)
    {
        $q="insert into miscdests (description,destdial) values ('".$data->description."','".$data->destination_dial."');";
        $query=$this->db->query($q);
        $misc_id = $this->db->insert_id();
        return $misc_id;
    }

    public function update_misc($data)
    {
        $q="update miscdests set description='".$data->description."',destdial='".$data->destination_dial."' where id=".$data->Misc_ID;
        $query=$this->db->query($q);
        return $this->db->affected_rows();
    }

    public function delete_misc($id)
    {
        $q="delete from miscdests where id=".$id;
        $query=$this->db->query($q);
        return $this->db->affected_rows();
    }
}

?>