<?php

class IVR_model extends CI_Model{
    
    public function get_ivr($id)
    {
	$pos = strpos($id, "ivr");
        if($pos === false){

            $q="select * from ivr_details where id=".$id;
            $query = $this->db->query($q);
            $ivr_details = $query->result_array();
            return $ivr_details;
	}else{
	        $readconf = file_get_contents("/etc/asterisk/extensions_custom.conf");
            $test = str_replace(array("\r", "\n"), '', $readconf);
            $string = explode(";;;;;;;CUSTOM IVR CODE START HERE IVR",$test);
            $header = $string[0];
            $body_and_foot =  explode(";;;;;END OF THE CUSTOM IVR CODE",$string[1]);
            $foot = $body_and_foot[1];
            $body = $body_and_foot[0];
            $lines = explode(";--== end of [ivr] ==--;",$body);
            $response = [];
            foreach($lines as $line){
                $obj =  [];
                $name_str = explode("[ivr",$line);
                if(!isset($name_str[1])){
                    continue;
                }
                $name_str2 = explode("]",$name_str[1]);
                
                $obj["IVRName"] = "ivr".$name_str2[0];
                $obj["type"] = "custom";
                  $extends =   explode("exten =>",$name_str2[1]);
                $ext = [];
                $ext_count = 0;
		        $i = 0;
                foreach($extends as $e){
                    $sames = explode("same",$e);
                    if($i > 1){
                    $number = explode(",",$sames[0]);

                    $desti = explode("goto(",$sames[0]);
                    $desti2 = explode(")",$desti[1]);
                    $distdet = new stdclass();

                    $distdet->digit = $number[0];

                    $distdet->destination = $desti2[0];

                    $distdet->return = 0;
                    $ext["Digits$number[0]:"] = $distdet;
                            $ext_count ++;
                    }
                    $i++;
                }

                $obj["ivr_entries"] = $ext;
                // print_r($id);
                if($obj["IVRName"] == $id){   
                   $response[] = $obj;
                }
            }
      
	    }
    return $response;
    }
    public function get_all_ivr()
    {
        $q="select * from ivr_details";
        $query = $this->db->query($q);
        $ivr_details = $query->result_array();
        $readconf = file_get_contents("/etc/asterisk/extensions_custom.conf");
        $test = str_replace(array("\r", "\n"), '', $readconf);
        $string = explode(";;;;;;;CUSTOM IVR CODE START HERE IVR",$test);
        $header = $string[0];
        $body_and_foot =  explode(";;;;;END OF THE CUSTOM IVR CODE",$string[1]);
        $foot = $body_and_foot[1];
        $body = $body_and_foot[0];

        $lines = explode(";--== end of [ivr] ==--;",$body);
        $test = [];
        // print_r($lines);
        foreach($lines as $line){
            $obj = new stdclass();
            $name_str = explode("[ivr",$line);
            if(isset($name_str[1])){
                $name_str2 = explode("]",$name_str[1]);
                $obj->id = "ivr".$name_str2[0];
                $obj->type = "custom";
                $ivr_details[] = $obj;
            }else{
                $obj->id = "not read";
                $obj->type = "not read";
            }
            
         
        }
	//$test = [];
	//return $test;
	return $ivr_details;
    }

    public function get_ivr_entries($ivrid)
    {
	$pos = strpos($ivrid, "ivr");
        if($pos === false){
        $q="select * from ivr_entries where ivr_id=".$ivrid;
        $query1 = $this->db->query($q);
        return $query1->result_array();
	}else{
	return [];
	}
    }

    public function update_ivr_entries($ivrid,$selection,$dest,$ivr_ret)
    {
        $q="update ivr_entries set selection=".$selection.",dest='".$dest."',ivr_ret='".$ivr_ret."' where ivr_id=".$ivrid." and selection=".$selection;
        $query1 = $this->db->query($q);
        return $this->db->affected_rows();
    }

    public function check_ivr_entries($ivrid,$digit)
    {
        $q="select * from ivr_entries where ivr_id=".$ivrid." and selection=".$digit;
        $query1 = $this->db->query($q);
        return $query1->result_array();
    }

    public function create_ivr($data)
    {

        if(isset($data->type) && $data->type == "custom"){

            $digits=get_object_vars($data);

            $new_digits = "";
            foreach($digits as $key => $value){
                $n_digit = "";
                
                if($key == "Digits*"){
                   $n_digit = 
                   "exten =>*,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits#"){
                    $n_digit = 
                    "exten =>#,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits0"){
                    $n_digit = 
                    "exten =>0,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits1"){
                    $n_digit = 
                    "exten =>1,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits2"){
                    $n_digit = 
                    "exten =>2,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits3"){
                    $n_digit = 
                    "exten =>3,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits4"){
                    $n_digit = 
                    "exten =>4,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits5"){
                    $n_digit = 
                    "exten =>5,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits6"){
                    $n_digit = 
                    "exten =>6,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits7"){
                    $n_digit = 
                    "exten =>7,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits8"){
                    $n_digit = 
                    "exten =>8,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits9"){
                    $n_digit = 
                    "exten =>9,1,goto($value->destination)\nsame>n,Hangup()";
                }
                if($n_digit != ""){
                    $new_digits .=$n_digit."\n\n";
                }
            }

            // print_r($new_digits);


$id = "[".$data->IVRName."]";

$new_line = $id.'
exten=>100,1,Set(GLOBAL(LOOPCOUNT)=1)
same=>n,verbose(value of ${LOOPCOUNT} ${cid})

same=>n,Answer()
same=>n,Background(/var/lib/asterisk/sounds/custom/outputs/'.$data->IVRName.'_${cid})
same=>n,Waitexten(10)

exten =>i,1,Playback(option-is-invalid)
same=>n,Goto('.$data->IVRName.',100,1)

same=>n,Hangup()

'.$new_digits.'
exten=>t,1,NoOp()
same=>n,Set(LOOPCOUNT=$[${LOOPCOUNT} + 1])
same=>n,verbose(value of ${LOOPCOUNT})
same=>n,GotoIf($[${LOOPCOUNT} > 2]?hangup,hang,1)
same=>n,Goto('.$data->IVRName.',100,1)

;--== end of [ivr] ==--;

;;;;;END OF THE CUSTOM IVR CODE';
        



// 



            $readconf = file_get_contents("/etc/asterisk/extensions_custom.conf");
            $check = explode("[$data->IVRName]",$readconf);
            if(count($check)  > 1){
                return "allready exist";
            }else{
                $read_arr = explode(";;;;;END OF THE CUSTOM IVR CODE",$readconf);
                $before = $read_arr[0];
                $after = $read_arr[1];
                $new_write = $before.$new_line.$after;
                file_put_contents("/etc/asterisk/extensions_custom.conf",$new_write);
            
                return $id;
            }
        }else{

            $q="insert into ivr_details (name,description,announcement,strict_dial_timeout,timeout_time,alertinfo,rvolume,invalid_loops,
            invalid_retry_recording,invalid_append_announce,invalid_ivr_ret,invalid_recording,invalid_destination,timeout_loops,
            timeout_retry_recording,timeout_append_announce,timeout_ivr_ret,timeout_recording,timeout_destination,retvm)
            values
            ('".$data->IVRName."','".$data->IVRDescription."','".$data->Announcement."','".$data->ForceStrictDialTimeout."','".$data->Timeout."','".$data->AlertInfo."',
            '".$data->RingerVolumeOverride."','".$data->InvalidRetries."','".$data->InvalidRetryRecording."','".$data->AppendAnnouncementtoInvalid."','".$data->ReturnonInvalid."','".$data->InvalidRecording."',
            '".$data->InvalidDestination."','".$data->TimeoutRetries."','".$data->TimeoutRetryRecording."','".$data->AppendAnnouncementonTimeout."','".$data->ReturnonTimeout."','".$data->TimeoutRecording."',
            '".$data->TimeoutDestination."','".$data->ReturntoIVRafterVM."');";
            $query=$this->db->query($q);
            $ivr_id = $this->db->insert_id();
            return $ivr_id;
        }
    }

    public function update_ivr($data)
    {
        // die("here");
        // print_r($data->type);
        if($data->type == "custom"){

            $digits=get_object_vars($data);

            $new_digits = "";
            foreach($digits as $key => $value){
                $n_digit = "";
                
                if($key == "Digits*"){
                   $n_digit = 
                   "exten =>*,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits#"){
                    $n_digit = 
                    "exten =>#,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits0"){
                    $n_digit = 
                    "exten =>0,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits1"){
                    $n_digit = 
                    "exten =>1,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits2"){
                    $n_digit = 
                    "exten =>2,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits3"){
                    $n_digit = 
                    "exten =>3,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits4"){
                    $n_digit = 
                    "exten =>4,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits5"){
                    $n_digit = 
                    "exten =>5,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits6"){
                    $n_digit = 
                    "exten =>6,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits7"){
                    $n_digit = 
                    "exten =>7,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits8"){
                    $n_digit = 
                    "exten =>8,1,goto($value->destination)\nsame>n,Hangup()";
                }
                elseif($key == "Digits9"){
                    $n_digit = 
                    "exten =>9,1,goto($value->destination)\nsame>n,Hangup()";
                }
                if($n_digit != ""){
                    $new_digits .=$n_digit."\n\n";
                }
            }

            // print_r($new_digits);


$id = "[".$data->IVR_ID."]";

$new_line = $id.'
exten=>100,1,Set(GLOBAL(LOOPCOUNT)=1)
same=>n,verbose(value of ${LOOPCOUNT} ${cid})

same=>n,Answer()
same=>n,Background(/var/lib/asterisk/sounds/custom/'.$data->IVR_ID.'_${cid})
same=>n,Waitexten(10)

exten =>i,1,Playback(option-is-invalid)
same=>n,Goto('.$data->IVR_ID.',100,1)

same=>n,Hangup()

'.$new_digits.'
exten=>t,1,NoOp()
same=>n,Set(LOOPCOUNT=$[${LOOPCOUNT} + 1])
same=>n,verbose(value of ${LOOPCOUNT})
same=>n,GotoIf($[${LOOPCOUNT} > 2]?hangup,hang,1)
same=>n,Goto('.$data->IVR_ID.',100,1)

;--== end of [ivr] ==--;';
        
            $readconf = file_get_contents("/etc/asterisk/extensions_custom.conf");
            $read_arr = explode("[$data->IVR_ID]",$readconf);

            // 
            
            if(count($read_arr)  > 1){
            $read_arr2 = explode(";--== end of [ivr] ==--;",$read_arr[1]);
            $before = $read_arr[0];
            $after = "";
            if(count($read_arr2) == 2){
                $after = $read_arr2[1];
            }else{
                foreach($read_arr2 as $arkey => $r_ar){
                    if($arkey != 0){
                        if((count($read_arr2)-1) == $arkey){
                            $after .= $r_ar;
                        }else{
                            $after .= $r_ar."\n;--== end of [ivr] ==--;";
                        }
                       
                    }
                }
            }
          
            $new_write = $before.$new_line.$after;
            // print_r($read_arr);
            // echo $new_write;
            file_put_contents("/etc/asterisk/extensions_custom.conf",$new_write);
        
                return $id;
            }else{
                // print_r("123");
                return "not found";
            }
        }else{

        $q="update ivr_details
        set name='".$data->IVRName."',description='".$data->IVRDescription."',announcement='".$data->Announcement."',strict_dial_timeout='".$data->ForceStrictDialTimeout."',
        timeout_time='".$data->Timeout."',alertinfo='".$data->AlertInfo."',rvolume='".$data->RingerVolumeOverride."',
        invalid_loops='".$data->InvalidRetries."',invalid_retry_recording='".$data->InvalidRetryRecording."',
        invalid_append_announce='".$data->AppendAnnouncementtoInvalid."',invalid_ivr_ret='".$data->ReturnonInvalid."',invalid_recording='".$data->InvalidRecording."',invalid_destination='".$data->InvalidDestination."',
        timeout_loops='".$data->TimeoutRetries."',timeout_retry_recording='".$data->TimeoutRetryRecording."',timeout_append_announce='".$data->AppendAnnouncementonTimeout."',timeout_ivr_ret='".$data->ReturnonTimeout."',
        timeout_recording='".$data->TimeoutRecording."',timeout_destination='".$data->TimeoutDestination."',retvm='".$data->ReturntoIVRafterVM."'
        where id=".$data->IVR_ID;
        $query=$this->db->query($q);
        return $this->db->affected_rows();
        }
    }

    public function insert_ivr_entries($data,$ivr_id)
    {
        $q="insert into ivr_entries (ivr_id,selection,dest,ivr_ret) values ('".$ivr_id."','".$data->digit."','".$data->destination."','".$data->return."')";
        $query=$this->db->query($q);
        $ivr_id = $this->db->insert_id();
        return $ivr_id;
    }

    public function delete_ivr_entries($ivr_id)
    {
        $q="delete from ivr_entries where ivr_id=".$ivr_id;
        $query=$this->db->query($q);
        return $this->db->affected_rows();
    }

    public function delete_ivr($id)
    {
        $pos = strpos($id, "ivr");
        if($pos === false){

        $q="delete from ivr_details where id=".$id;
        $query=$this->db->query($q);
        return $this->db->affected_rows();
        }else{
            $readconf = file_get_contents("/etc/asterisk/extensions_custom.conf");
            $read_arr = explode("[$id]",$readconf);

            if(count($read_arr)  > 1){
                $read_arr2 = explode(";--== end of [ivr] ==--;",$read_arr[1]);
                $before = $read_arr[0];
                $after = "";
                if(count($read_arr2) == 2){
                    $after = $read_arr2[1];
                }else{
                    foreach($read_arr2 as $arkey => $r_ar){
                        if($arkey != 0){
                            if((count($read_arr2)-1) == $arkey){
                                $after .= $r_ar;
                            }else{
                                $after .= $r_ar."\n;--== end of [ivr] ==--;";
                            }
                        
                        }
                    }
                }
            
                $new_write = $before.$after;
                // print_r($read_arr);
                // echo $new_write;
                file_put_contents("/etc/asterisk/extensions_custom.conf",$new_write);
                return true;
            }else{
                return false;
            }
        }
    }

}



?>
